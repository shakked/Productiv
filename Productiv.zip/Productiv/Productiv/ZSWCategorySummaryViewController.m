//
//  ZSWCategorySummaryViewController.m
//  Productiv
//
//  Created by Zachary Shakked on 7/30/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import "ZSWCategorySummaryViewController.h"
#import "ZSWTask.h"
#import "ZSWTaskStore.h"
#import <MagicPieLayer.h>
#import "PieLayer.h"
#import "ZSWTaskByCategoryTableViewController.h"

@interface ZSWCategorySummaryViewController ()

@property (nonatomic, strong) UIScrollView *scrollView;

@end

@implementation ZSWCategorySummaryViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor whiteColor];
        CGRect screenRect = self.view.bounds; //the overall big one
        CGRect bigRect = screenRect; //the big rect
        bigRect.size.height *= 1.3; //enlarge the size by 2.0
        
        //Create a screen-sized scroll view and add it to the window
        self.scrollView = [[UIScrollView alloc] initWithFrame:screenRect];
        self.scrollView.contentSize = bigRect.size;
        [self.view addSubview:self.scrollView];
        
        //Main View
        UIView *view = [[UIView alloc] initWithFrame:bigRect];
        view.backgroundColor = [UIColor whiteColor];
        [self.scrollView addSubview:view];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    //navigation
    NSString *categoryName = [self.category valueForKey:@"name"];
    self.navigationItem.title = categoryName;
    
    NSDictionary *stats = [[ZSWTaskStore sharedStore] stats];
    NSDictionary *categoryStats = [stats valueForKey:@"categoryStats"];
    NSDictionary *categoryDictionary = [categoryStats valueForKey:categoryName];
    
    
    //Colors
    NSDictionary *colors = [[ZSWTaskStore sharedStore] colors];
    UIColor *color = [colors valueForKey:@"productiveGreen"];
    UIColor *lightGray = [colors valueForKey:@"lightGray"];
    
    //data
    
    NSNumber *totalNumberOfTasks = [categoryDictionary valueForKey:@"numberOfTasks"];
    NSNumber *totalNumberOfCompleteTasks = [categoryDictionary valueForKey:@"totalNumberOfCompleteTasks"];
    NSNumber *totalNumberOfIncompleteTasks = [categoryDictionary valueForKey:@"totalNumberOfIncompleteTasks"];
    NSNumber *percentageOfTasksInThisCategory = [categoryDictionary valueForKey:@"percentageOfTasksInThisCategory"];
    
    NSManagedObject *favoriteCategory = [stats valueForKey:@"favoriteCategory"];
    BOOL isFavoriteCategory = NO;
    if (favoriteCategory == self.category) {
        isFavoriteCategory = YES;
    }
    
    float percentageOfTasksCompleted = totalNumberOfCompleteTasks.floatValue / totalNumberOfTasks.floatValue;
    percentageOfTasksCompleted *= 100;
    

    //Total number of tasks label
    CGRect percentageOfTasksLabelFrame = CGRectMake(10, 10, self.view.frame.size.width - 20, 60);
    UILabel *percentageOfTasksLabel = [[UILabel alloc] initWithFrame:percentageOfTasksLabelFrame];
    percentageOfTasksLabel.textAlignment = NSTextAlignmentCenter;
    percentageOfTasksLabel.textColor = color;
    percentageOfTasksLabel.backgroundColor = [UIColor whiteColor];
    percentageOfTasksLabel.numberOfLines = 0;
    [[percentageOfTasksLabel layer] setBorderColor:color.CGColor];
    [[percentageOfTasksLabel layer] setBorderWidth:1.0];
    [[percentageOfTasksLabel layer] setCornerRadius:7.0];
    percentageOfTasksLabel.font = [UIFont fontWithName:@"Avenir" size:17.0];
    //formatting string
    NSString *percentageCompletedString = [NSString stringWithFormat:@"You've completed:\n %.2f%% of your %@ tasks.", percentageOfTasksCompleted, categoryName];
    //range for category and percent
    NSRange rangeForBoldedPercentage = [percentageCompletedString rangeOfString:@"."];
    NSRange categoryRange = [percentageCompletedString rangeOfString:categoryName];
    NSRange range;
    if (percentageOfTasksCompleted > 99.99) {
        range = NSMakeRange(rangeForBoldedPercentage.location - 3, 7);
    }else if (percentageOfTasksCompleted > 9.99) {
        range = NSMakeRange(rangeForBoldedPercentage.location - 2, 6);
    }else {
        range = NSMakeRange(rangeForBoldedPercentage.location - 1, 5);
    }
    NSMutableAttributedString * string = [[NSMutableAttributedString alloc] initWithString:percentageCompletedString];
    
    if (totalNumberOfTasks.intValue != 0) {
        [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:17.0] range:range];
        [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:17.0] range:categoryRange];
        
        percentageOfTasksLabel.attributedText = string;
        
        //Pie Graph
        PieLayer *pieLayer = [[PieLayer alloc] init];
        pieLayer.frame = CGRectMake(0, 30, self.view.frame.size.width, 300);
        
        [pieLayer addValues:@[[PieElement pieElementWithValue:totalNumberOfCompleteTasks.intValue color:color],
                              [PieElement pieElementWithValue:totalNumberOfIncompleteTasks.intValue color:lightGray]] animated:YES];
        
        [self.scrollView.layer addSublayer:pieLayer];
    } else {
        percentageOfTasksLabel.text = @"You haven't made any tasks in this category.";
    }
    [self.scrollView addSubview:percentageOfTasksLabel];

    //more labels
    //total number of tasks
        //button
    UIButton *totalNumberOfTasksButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 290, self.view.frame.size.width - 20, 30)];
    [totalNumberOfTasksButton addTarget:self
                                 action:@selector(showAllTasks)
                       forControlEvents:UIControlEventTouchUpInside];
    totalNumberOfTasksButton.backgroundColor = [UIColor clearColor];
    [totalNumberOfTasksButton setTitle:@"" forState:UIControlStateNormal];
    
    CGRect totalNumberOfTasksLabelFrame = CGRectMake(10, 290, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfTasksLabelFrame];
    totalNumberOfTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfTasksLabel.textColor = [UIColor whiteColor];
    totalNumberOfTasksLabel.backgroundColor = color;
    totalNumberOfTasksLabel.numberOfLines = 0;
    [[totalNumberOfTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *totalNumberOfTasksString = [NSString stringWithFormat:@"Total number of tasks: %d", totalNumberOfTasks.intValue];
    NSRange rangeForColon = [totalNumberOfTasksString rangeOfString:@":"];
    NSInteger length = [totalNumberOfTasks.stringValue length];
    NSRange rangeForTotalNumberOfTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfTasksStringFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfTasksString];
    [totalNumberOfTasksStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfTasks];
    totalNumberOfTasksLabel.attributedText = totalNumberOfTasksStringFormatted;
    
    [self.scrollView addSubview:totalNumberOfTasksButton];
    [self.scrollView addSubview:totalNumberOfTasksLabel];
    
    //total number of complete tasks
    UIButton *totalNumberOfCompleteTasksButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 330, self.view.frame.size.width - 20, 30)];
    [totalNumberOfCompleteTasksButton addTarget:self
                                 action:@selector(showAllCompleteTasks)
                       forControlEvents:UIControlEventTouchUpInside];
    totalNumberOfTasksButton.backgroundColor = [UIColor clearColor];
    [totalNumberOfTasksButton setTitle:@"" forState:UIControlStateNormal];
    CGRect totalNumberOfCompleteTasksLabelFrame = CGRectMake(10, 330, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfCompleteTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfCompleteTasksLabelFrame];
    totalNumberOfCompleteTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfCompleteTasksLabel.textColor = [UIColor whiteColor];
    totalNumberOfCompleteTasksLabel.backgroundColor = color;
    totalNumberOfCompleteTasksLabel.numberOfLines = 0;
    [[totalNumberOfCompleteTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfCompleteTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *totalNumberOfCompleteTasksString = [NSString stringWithFormat:@"Total number of complete tasks: %d", totalNumberOfCompleteTasks.intValue];
    rangeForColon = [totalNumberOfCompleteTasksString rangeOfString:@":"];
    length = [totalNumberOfCompleteTasks.stringValue length];
    NSRange rangeForTotalNumberOfCompleteTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfCompleteTasksFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfCompleteTasksString];
    [totalNumberOfCompleteTasksFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfCompleteTasks];
    totalNumberOfCompleteTasksLabel.attributedText = totalNumberOfCompleteTasksFormatted;
    
    [self.scrollView addSubview:totalNumberOfCompleteTasksButton];
    [self.scrollView addSubview:totalNumberOfCompleteTasksLabel];
    
    //total number of incomplete tasks
    UIButton *totalNumberOfIncompleteTasksButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 370, self.view.frame.size.width - 20, 30)];
    [totalNumberOfIncompleteTasksButton addTarget:self
                                 action:@selector(showAllIncompleteTasks)
                       forControlEvents:UIControlEventTouchUpInside];
    totalNumberOfTasksButton.backgroundColor = [UIColor clearColor];
    [totalNumberOfTasksButton setTitle:@"" forState:UIControlStateNormal];
    CGRect totalNumberOfIncompleteTasksLabelFrame = CGRectMake(10, 370, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfIncompleteTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfIncompleteTasksLabelFrame];
    totalNumberOfIncompleteTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfIncompleteTasksLabel.textColor = [UIColor whiteColor];
    totalNumberOfIncompleteTasksLabel.backgroundColor = color;
    totalNumberOfIncompleteTasksLabel.numberOfLines = 0;
    [[totalNumberOfIncompleteTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfIncompleteTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *totalNumberOfIncompleteTasksString = [NSString stringWithFormat:@"Total number of incomplete tasks: %d", totalNumberOfIncompleteTasks.intValue];
    rangeForColon = [totalNumberOfIncompleteTasksString rangeOfString:@":"];
    length = [totalNumberOfIncompleteTasks.stringValue length];
    NSRange rangeForTotalNumberOfIncompleteTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfIncompleteTasksStringFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfIncompleteTasksString];
    [totalNumberOfIncompleteTasksStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfIncompleteTasks];
    totalNumberOfIncompleteTasksLabel.attributedText = totalNumberOfIncompleteTasksStringFormatted;
    
    [self.scrollView addSubview:totalNumberOfIncompleteTasksButton];
    [self.scrollView addSubview:totalNumberOfIncompleteTasksLabel];

}

- (void)showAllTasks
{
    ZSWTaskByCategoryTableViewController *tbct = [[ZSWTaskByCategoryTableViewController alloc] init];
    tbct.category = self.category;
    tbct.segIndex = 0;
    [self.navigationController pushViewController:tbct animated:YES];
}
- (void)showAllCompleteTasks
{
    ZSWTaskByCategoryTableViewController *tbct = [[ZSWTaskByCategoryTableViewController alloc] init];
    tbct.category = self.category;
    tbct.segIndex = 1;
    [self.navigationController pushViewController:tbct animated:YES];
}

- (void)showAllIncompleteTasks
{
    ZSWTaskByCategoryTableViewController *tbct = [[ZSWTaskByCategoryTableViewController alloc] init];
    tbct.category = self.category;
    tbct.segIndex = 2;
    [self.navigationController pushViewController:tbct animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
