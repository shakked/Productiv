//
//  ZSWDetailViewController.h
//  Productiv
//
//  Created by Zachary Shakked on 7/20/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZSWTask.h"

@interface ZSWDetailViewController : UIViewController

@property (nonatomic, weak) ZSWTask *task;

@end
