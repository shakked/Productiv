//
//  ZSWNewCategoryViewController.h
//  Productiv
//
//  Created by Zachary Shakked on 7/19/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZSWNewCategoryViewController : UIViewController

@property (nonatomic, weak) NSString *category;

@end
