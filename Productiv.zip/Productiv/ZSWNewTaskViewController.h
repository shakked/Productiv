//
//  ZSWNewTaskViewController.h
//  Productiv
//
//  Created by Zachary Shakked on 7/19/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ZSWTask;

@interface ZSWNewTaskViewController : UIViewController

@property (nonatomic, strong) ZSWTask *task;

@end
