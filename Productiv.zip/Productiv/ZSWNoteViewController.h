//
//  ZSWNoteViewController.h
//  Productiv
//
//  Created by Zachary Shakked on 7/21/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZSWTask.h"


@interface ZSWNoteViewController : UIViewController

@property (nonatomic, weak) ZSWTask *task;

@end
