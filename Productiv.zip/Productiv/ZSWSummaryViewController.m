//
//  ZSWSummaryViewController.m
//  Productiv
//
//  Created by Zachary Shakked on 7/25/14.
//  Copyright (c) 2014 Productiv. All rights reserved.
//

#import "ZSWSummaryViewController.h"
#import "ZSWTaskStore.h"
#import <MagicPieLayer.h>
#import "PieLayer.h"

@interface ZSWSummaryViewController ()

@property (nonatomic, strong) UIScrollView *scrollView;

@end

@implementation ZSWSummaryViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

        self.view.backgroundColor = [UIColor whiteColor];
        CGRect screenRect = self.view.bounds; //the overall big one
        CGRect bigRect = screenRect; //the big rect
        bigRect.size.height *= 1,3; //enlarge the size by 2.0
        
        
        //Create a screen-sized scroll view and add it to the window
        self.scrollView = [[UIScrollView alloc] initWithFrame:screenRect];
         self.scrollView.contentSize = bigRect.size;
        [self.view addSubview:self.scrollView];
        
        //Main View
        UIView *view = [[UIView alloc] initWithFrame:bigRect];
        view.backgroundColor = [UIColor whiteColor];
        [self.scrollView addSubview:view];
        
        self.navigationItem.title = @"Task Summary";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
    NSDictionary *stats = [[ZSWTaskStore sharedStore] stats];
    
    //Colors
    NSDictionary *colors = [[ZSWTaskStore sharedStore] colors];
    UIColor *color = [colors valueForKey:@"productiveGreen"];
    UIColor *lightGray = [colors valueForKey:@"lightGray"];

    //data

    NSNumber *totalNumberOfTasks = [stats valueForKey:@"totalNumberOfTasks"];
    NSNumber *totalNumberOfCompleteTasks = [stats valueForKey:@"totalNumberOfCompleteTasks"];
    NSNumber *totalNumberOfIncompleteTasks = [stats valueForKey:@"totalNumberOfIncompleteTasks"];
    NSNumber *averageNumberOfTasksPerDay = [stats valueForKey:@"averageNumberOfTasksPerDay"];

    NSManagedObject *favoriteCategory = [stats valueForKey:@"favoriteCategory"];

    float percentageOfTasksCompleted = totalNumberOfCompleteTasks.floatValue / totalNumberOfTasks.floatValue;
    percentageOfTasksCompleted *= 100;

    
    //Total number of tasks label
    CGRect percentageOfTasksLabelFrame = CGRectMake(10, 10, self.view.frame.size.width - 20, 30);
    UILabel *percentageOfTasksLabel = [[UILabel alloc] initWithFrame:percentageOfTasksLabelFrame];
    percentageOfTasksLabel.textAlignment = NSTextAlignmentCenter;
    percentageOfTasksLabel.textColor = color;
    percentageOfTasksLabel.backgroundColor = [UIColor whiteColor];
    percentageOfTasksLabel.numberOfLines = 0;
    [[percentageOfTasksLabel layer] setBorderColor:color.CGColor];
    [[percentageOfTasksLabel layer] setBorderWidth:1.0];
    [[percentageOfTasksLabel layer] setCornerRadius:7.0];
    percentageOfTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
            //formatting string
    NSString *percentageCompletedString = [NSString stringWithFormat:@"You've completed %.2f%% of your tasks.", percentageOfTasksCompleted];
    NSRange rangeForBoldedPercentage = [percentageCompletedString rangeOfString:@"."];
    NSRange range;
    if (percentageOfTasksCompleted > 99.99) {
        range = NSMakeRange(rangeForBoldedPercentage.location - 3, 7);
    }else if (percentageOfTasksCompleted > 9.99) {
        range = NSMakeRange(rangeForBoldedPercentage.location - 2, 6);
    }else {
        range = NSMakeRange(rangeForBoldedPercentage.location - 1, 5);
    }
    NSMutableAttributedString * string = [[NSMutableAttributedString alloc] initWithString:percentageCompletedString];
    
    if (totalNumberOfTasks.intValue != 0) {
        [string addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:range];
        percentageOfTasksLabel.attributedText = string;

        //Pie Graph
        PieLayer *pieLayer = [[PieLayer alloc] init];
        pieLayer.frame = CGRectMake(0, 0, self.view.frame.size.width, 300);
        
        [pieLayer addValues:@[[PieElement pieElementWithValue:totalNumberOfCompleteTasks.intValue color:color],
                              [PieElement pieElementWithValue:totalNumberOfIncompleteTasks.intValue color:lightGray]] animated:YES];
        
        [self.scrollView.layer addSublayer:pieLayer];
    } else {
        percentageOfTasksLabel.text = @"You haven't made any tasks.";
    }
    [self.scrollView addSubview:percentageOfTasksLabel];

    //more labels
    //total number of tasks
    CGRect totalNumberOfTasksLabelFrame = CGRectMake(10, 260, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfTasksLabelFrame];
    totalNumberOfTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfTasksLabel.textColor = color;
    totalNumberOfTasksLabel.backgroundColor = [UIColor whiteColor];
    totalNumberOfTasksLabel.numberOfLines = 0;
    [[totalNumberOfTasksLabel layer] setBorderColor:color.CGColor];
    [[totalNumberOfTasksLabel layer] setBorderWidth:1.0];
    [[totalNumberOfTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
        //format string
    NSString *totalNumberOfTasksString = [NSString stringWithFormat:@"Total number of tasks: %d", totalNumberOfTasks.intValue];
    NSRange rangeForColon = [totalNumberOfTasksString rangeOfString:@":"];
    NSInteger length = [totalNumberOfTasks.stringValue length];
    NSRange rangeForTotalNumberOfTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfTasksStringFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfTasksString];
    [totalNumberOfTasksStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfTasks];
    totalNumberOfTasksLabel.attributedText = totalNumberOfTasksStringFormatted;
    
    [self.scrollView addSubview:totalNumberOfTasksLabel];
    
    //total number of complete tasks
    CGRect totalNumberOfCompleteTasksLabelFrame = CGRectMake(10, 300, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfCompleteTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfCompleteTasksLabelFrame];
    totalNumberOfCompleteTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfCompleteTasksLabel.textColor = color;
    totalNumberOfCompleteTasksLabel.backgroundColor = [UIColor whiteColor];
    totalNumberOfCompleteTasksLabel.numberOfLines = 0;
    [[totalNumberOfCompleteTasksLabel layer] setBorderColor:color.CGColor];
    [[totalNumberOfCompleteTasksLabel layer] setBorderWidth:1.0];
    [[totalNumberOfCompleteTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfCompleteTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *totalNumberOfCompleteTasksString = [NSString stringWithFormat:@"Total number of complete tasks: %d", totalNumberOfCompleteTasks.intValue];
    rangeForColon = [totalNumberOfCompleteTasksString rangeOfString:@":"];
    length = [totalNumberOfCompleteTasks.stringValue length];
    NSRange rangeForTotalNumberOfCompleteTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfCompleteTasksFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfCompleteTasksString];
    [totalNumberOfCompleteTasksFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfCompleteTasks];
    totalNumberOfCompleteTasksLabel.attributedText = totalNumberOfCompleteTasksFormatted;
    
    [self.scrollView addSubview:totalNumberOfCompleteTasksLabel];
    
    //total number of incomplete tasks
    CGRect totalNumberOfIncompleteTasksLabelFrame = CGRectMake(10, 340, self.view.frame.size.width - 20, 30);
    UILabel *totalNumberOfIncompleteTasksLabel = [[UILabel alloc] initWithFrame:totalNumberOfIncompleteTasksLabelFrame];
    totalNumberOfIncompleteTasksLabel.textAlignment = NSTextAlignmentCenter;
    totalNumberOfIncompleteTasksLabel.textColor = color;
    totalNumberOfIncompleteTasksLabel.backgroundColor = [UIColor whiteColor];
    totalNumberOfIncompleteTasksLabel.numberOfLines = 0;
    [[totalNumberOfIncompleteTasksLabel layer] setBorderColor:color.CGColor];
    [[totalNumberOfIncompleteTasksLabel layer] setBorderWidth:1.0];
    [[totalNumberOfIncompleteTasksLabel layer] setCornerRadius:7.0];
    totalNumberOfIncompleteTasksLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *totalNumberOfIncompleteTasksString = [NSString stringWithFormat:@"Total number of incomplete tasks: %d", totalNumberOfIncompleteTasks.intValue];
    rangeForColon = [totalNumberOfIncompleteTasksString rangeOfString:@":"];
    length = [totalNumberOfIncompleteTasks.stringValue length];
    NSRange rangeForTotalNumberOfIncompleteTasks = NSMakeRange(rangeForColon.location + 2, length);
    NSMutableAttributedString *totalNumberOfIncompleteTasksStringFormatted = [[NSMutableAttributedString alloc] initWithString:totalNumberOfIncompleteTasksString];
    [totalNumberOfIncompleteTasksStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForTotalNumberOfIncompleteTasks];
    totalNumberOfIncompleteTasksLabel.attributedText = totalNumberOfIncompleteTasksStringFormatted;
    
    [self.scrollView addSubview:totalNumberOfIncompleteTasksLabel];
    
    //Avg number of tasks per day
    CGRect averageNumberOfTasksPerDayFrame = CGRectMake(10, 380, self.view.frame.size.width - 20, 30);
    UILabel *averageNumberOfTasksPerDayLabel = [[UILabel alloc] initWithFrame:averageNumberOfTasksPerDayFrame];
    averageNumberOfTasksPerDayLabel.textAlignment = NSTextAlignmentCenter;
    averageNumberOfTasksPerDayLabel.textColor = color;
    averageNumberOfTasksPerDayLabel.backgroundColor = [UIColor whiteColor];
    averageNumberOfTasksPerDayLabel.numberOfLines = 0;
    [[averageNumberOfTasksPerDayLabel layer] setBorderColor:color.CGColor];
    [[averageNumberOfTasksPerDayLabel layer] setBorderWidth:1.0];
    [[averageNumberOfTasksPerDayLabel layer] setCornerRadius:7.0];
    averageNumberOfTasksPerDayLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSString *averageNumberOfTasksPerDayString = [NSString stringWithFormat:@"Average number of tasks per day: %.2f", averageNumberOfTasksPerDay.floatValue];
    rangeForColon = [averageNumberOfTasksPerDayString rangeOfString:@":"];
    length = [averageNumberOfTasksPerDay.stringValue length];
    NSRange rangeForAverageNumberOfTasksPerDay;
    if (averageNumberOfTasksPerDay.floatValue < 9.9999999999999) {
        rangeForAverageNumberOfTasksPerDay = NSMakeRange(rangeForColon.location + 2, 4);
    } else if(averageNumberOfTasksPerDay.floatValue < 99.99999999999) {
        rangeForAverageNumberOfTasksPerDay = NSMakeRange(rangeForColon.location + 2, 5);
    } else if (averageNumberOfTasksPerDay.floatValue < 999.9999999999999) {
        rangeForAverageNumberOfTasksPerDay = NSMakeRange(rangeForColon.location + 2, 6);
    }else {
        rangeForAverageNumberOfTasksPerDay = NSMakeRange(rangeForColon.location + 2, 3);
    }
    NSMutableAttributedString *averageNumberOfTasksPerDayStringFormatted = [[NSMutableAttributedString alloc] initWithString:averageNumberOfTasksPerDayString];
    [averageNumberOfTasksPerDayStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForAverageNumberOfTasksPerDay];
    averageNumberOfTasksPerDayLabel.attributedText = averageNumberOfTasksPerDayStringFormatted;

    [self.scrollView addSubview:averageNumberOfTasksPerDayLabel];
    
    //Favorite Category
    CGRect favoriteCategoryFrame = CGRectMake(10, 420, self.view.frame.size.width - 20, 30);
    UILabel *favoriteCategoryLabel = [[UILabel alloc] initWithFrame:favoriteCategoryFrame];
    favoriteCategoryLabel.textAlignment = NSTextAlignmentCenter;
    favoriteCategoryLabel.textColor = color;
    favoriteCategoryLabel.backgroundColor = [UIColor whiteColor];
    favoriteCategoryLabel.numberOfLines = 0;
    [[favoriteCategoryLabel layer] setBorderColor:color.CGColor];
    [[favoriteCategoryLabel layer] setBorderWidth:1.0];
    [[favoriteCategoryLabel layer] setCornerRadius:7.0];
    favoriteCategoryLabel.font = [UIFont fontWithName:@"Avenir" size:16.0];
    //format string
    NSLog(@"got here");
    if ([favoriteCategory valueForKey:@"name"]) {
        NSString *favoriteCategoryString = [NSString stringWithFormat:@"Favorite Category: %@", [favoriteCategory valueForKey:@"name"]];
        rangeForColon = [favoriteCategoryString rangeOfString:@":"];
        length = [[favoriteCategory valueForKey:@"name"] length];
        NSRange rangeForFavoriteCategory = NSMakeRange(rangeForColon.location + 2, length);
        NSMutableAttributedString *favoriteCategoryStringFormatted = [[NSMutableAttributedString alloc] initWithString:favoriteCategoryString];
        [favoriteCategoryStringFormatted addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Avenir-Heavy" size:16.0] range:rangeForFavoriteCategory];
        favoriteCategoryLabel.attributedText = favoriteCategoryStringFormatted;
    } else {
        favoriteCategoryLabel.text = @"No Favorite Category.";
    }
    
    [self.scrollView addSubview:favoriteCategoryLabel];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
