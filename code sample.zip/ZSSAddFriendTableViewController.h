//
//  ZSSAddFriendTableViewController.h
//  
//
//  Created by Zachary Shakked on 9/18/14.
//
//

#import <UIKit/UIKit.h>

@interface ZSSAddFriendTableViewController : UITableViewController

- (void)checkForFriendRequests;

@end
