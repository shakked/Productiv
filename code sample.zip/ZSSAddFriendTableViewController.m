//
//  ZSSAddFriendTableViewController.m
//  
//
//  Created by Zachary Shakked on 9/18/14.
//
//

#import "ZSSAddFriendTableViewController.h"
#import "ZSSInsultStore.h"
#import "ZSSFriendTableViewCell.h"
#import <Parse/Parse.h>

@interface ZSSAddFriendTableViewController () <UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSManagedObject *user;
@property (nonatomic, strong) NSArray *friendRequests;

@end

@implementation ZSSAddFriendTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
    UIColor *cloudBlue = [colors valueForKey:@"cloudBlue"];
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.tintColor = cloudBlue;
    self.navigationController.navigationBar.translucent = NO;
    self.navigationItem.title = @"Add Friends";
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           NSFontAttributeName : [UIFont fontWithName:@"Georgia" size:28.0],
                                                           NSForegroundColorAttributeName : cloudBlue
                                                           }];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];

    //back button
    UIButton *dismissViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    dismissViewButton.bounds = CGRectMake(0, 0, 28, 28);
    [dismissViewButton setBackgroundImage:[UIImage imageNamed:@"back-50.png"] forState:UIControlStateNormal];
    UIBarButtonItem *dismissViewBarButton = [[UIBarButtonItem alloc] initWithCustomView:dismissViewButton];
    [dismissViewButton addTarget:self action:@selector(dismissView) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = dismissViewBarButton;
    
    //register cell
    UINib *nib = [UINib nibWithNibName:@"ZSSFriendTableViewCell" bundle:nil];
    
    //Register this Nib, which contains the cell
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ZSSFriendTableViewCell"];
    self.tableView.allowsSelection = NO;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UINavigationBar appearance] setTitleTextAttributes:nil];
    //Register Current User for CoreData if not registered
    PFUser *currentUser = [PFUser currentUser];
    NSString *username = [currentUser valueForKey:@"username"];
    self.username = username;
    if (![[ZSSInsultStore sharedStore] coreIsUserRegistered:username]){
        [[ZSSInsultStore sharedStore] coreRegisterUserWithCoreData:username];
    }
    NSManagedObject *user = [[ZSSInsultStore sharedStore] coreUserWithUsername:self.username];
    self.user = user;
    
    //Background Check for Friends
    PFQuery *query = [PFQuery queryWithClassName:@"notification"];
    [query whereKey:@"receiver" equalTo:[PFUser currentUser]];
    [query whereKey:@"type" equalTo:@"friendRequest"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        for (PFObject *object in objects) {
            //check if there is already a friend with this status in CoreData
            if (![[ZSSInsultStore sharedStore] coreFriendExists:[[[object valueForKey:@"sender"]fetchIfNeeded] valueForKey:@"username"] forUser:self.user]){
                //If friend isn't already there, add him
                ZSSFriend *wantsToAddUserFriend = [[ZSSInsultStore sharedStore] coreCreateFriend];
                wantsToAddUserFriend.user = self.user;
                wantsToAddUserFriend.pending = @NO;
                wantsToAddUserFriend.wantsToAddUser = @YES;
                wantsToAddUserFriend.friendName = [[[object valueForKey:@"sender"]fetchIfNeeded] valueForKey:@"username"];
            }
        }
        NSLog(@"friends for user:%@", [[ZSSInsultStore sharedStore] coreAllFriendsForUser:self.user]);
        [[ZSSInsultStore sharedStore] saveChanges];
        NSLog(@"self.user: %@", self.user);
        NSLog(@"friends for said user: %@", [[ZSSInsultStore sharedStore] coreAllFriendsForUser:self.user]);
        NSLog(@"pendingFriends for user: %@", [[ZSSInsultStore sharedStore] corePendingFriendsForUser:self.user]);
        NSLog(@"wantToAddUserFriends: %@", [[ZSSInsultStore sharedStore] coreFriendRequestsForUser:self.user]);
        [self.tableView reloadData];
    }];
    
    //If there is a message object set
    //AND
    //If there is a sendlist
    //
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
    UIColor *superLightGray = [colors valueForKey:@"superLightGray"];
    self.searchBar.barTintColor = superLightGray;
    NSIndexPath *newFriendIndexPath = [NSIndexPath indexPathForRow:0
                                                         inSection:0];
    if (searchText.length != 0) {
        
        if (![self.tableView cellForRowAtIndexPath:newFriendIndexPath]) {
            [self.tableView insertRowsAtIndexPaths:@[newFriendIndexPath]
                                  withRowAnimation:UITableViewRowAnimationNone];
        }
        
        [self.tableView reloadRowsAtIndexPaths:@[newFriendIndexPath]
                              withRowAnimation:UITableViewRowAnimationNone];
    } else {
        if ([self.tableView cellForRowAtIndexPath:newFriendIndexPath]) {
            [self.tableView deleteRowsAtIndexPaths:@[newFriendIndexPath] withRowAnimation:UITableViewRowAnimationNone];
        }
        
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0){
        return 40;
    } else {
        return 0;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0){
        NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
        UIColor *superLightGray = [colors valueForKey:@"superLightGray"];
        self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 40)];
        self.searchBar.placeholder = @"Enter a Username";
        self.searchBar.barTintColor = superLightGray;
        self.searchBar.keyboardType = UIKeyboardTypeAlphabet;
        self.searchBar.returnKeyType = UIReturnKeyDefault;
        self.searchBar.autocapitalizationType = UITextAutocapitalizationTypeNone;
        self.searchBar.autocorrectionType = UITextAutocorrectionTypeNo;
        self.searchBar.delegate = self;
        return self.searchBar;
    } else {
        return nil;
    }
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    if (section == 0) {
        //see if the user is adding a new friend
        if (self.searchBar.text.length != 0) {
            return 1;
        } else {
            return 0;
        }
    } else if (section == 1) {
#pragma mark - Sent Friend Requests
        NSArray *sentFriendRequests = [[ZSSInsultStore sharedStore] corePendingFriendsForUser:self.user];
        if ([sentFriendRequests count] != 0) {
            return [sentFriendRequests count];
        }else {
            return 0;
        }

    } else if (section == 2) {
#pragma mark - Received Friend Requests
        NSArray *friendRequests = [[ZSSInsultStore sharedStore] coreFriendRequestsForUser:self.user];
        NSLog(@"friendRequests for user: %@", friendRequests);
        if ([friendRequests count] != 0) {
            return [friendRequests count];
        }else {
            return 0;
        }

    }
    return 0;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZSSFriendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ZSSFriendTableViewCell"
                                                                   forIndexPath:indexPath];
    
    if (indexPath.section == 0) {
        //check if there is text in the searchview
        if (self.searchBar.text.length != 0) {
            NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
            UIColor *cloudBlue = [colors valueForKey:@"cloudBlue"];
            [[cell.addFriendButton layer] setCornerRadius:5.0];
            [[cell.addFriendButton layer] setBorderColor:cloudBlue.CGColor];
            [[cell.addFriendButton layer] setBorderWidth:2.0];
            cell.friendLabel.text = self.searchBar.text;
            cell.actionBlock = ^{
                [self addFriend];
            };
        }else {
            [self.tableView reloadData];
        }
    } else if (indexPath.section == 1) {
#pragma mark - Sent Friend Requests Cells
        NSArray *pendingFriends = [[ZSSInsultStore sharedStore] corePendingFriendsForUser:self.user];
        pendingFriends = [[pendingFriends reverseObjectEnumerator] allObjects];
        if ([pendingFriends count] != 0) {
            NSManagedObject *pendingFriend = pendingFriends[indexPath.row];
            cell.friendLabel.text = [pendingFriend valueForKey:@"friendName"];
            [cell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"requestPending.png"] forState:UIControlStateNormal];
            

        }
    } else if (indexPath.section == 2) {
#pragma mark - Received Friend Requests

        NSArray *friendRequests = [[ZSSInsultStore sharedStore] coreFriendRequestsForUser:self.user];
        if ([friendRequests count] != 0) {
            NSManagedObject *requestingFriend = friendRequests[indexPath.row];
            NSString *requestingFriendUsername = [requestingFriend valueForKey:@"friendName"];
            cell.friendLabel.text = requestingFriendUsername;
            [cell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"addFriendButton.png"] forState:UIControlStateNormal];
            //__weak ZSSFriendTableViewCell *weakCell = cell;
            cell.actionBlock = ^{
                [self acceptFriendRequestFromFriendWithName:requestingFriendUsername];
            };
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dismissView
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)addFriend
{
#pragma mark - Send Friend Request
    if (self.searchBar.text.length > 0) {
        PFUser *receiver = [[ZSSInsultStore sharedStore] findUserWithUsername:self.searchBar.text];
        if (receiver) {
            if (![self.searchBar.text isEqualToString:[[PFUser currentUser] valueForKey:@"username"]]){
                if (![[ZSSInsultStore sharedStore] alreadySentRequestWithReceiver:receiver withSender:[PFUser currentUser]]){
                    //Parse
                    [[ZSSInsultStore sharedStore] sendFriendRequestWithReceiver:receiver
                                                                     withSender:[PFUser currentUser]];
                    
                    //CoreData
                    ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreCreateFriend];
                    friend.user = self.user;
                    friend.pending = @YES;
                    friend.wantsToAddUser = @NO;
                    friend.friendName = self.searchBar.text;
                    [[ZSSInsultStore sharedStore] saveChanges];
                    [self.tableView reloadData];
                    self.searchBar.text = @"";
                }else {
                    NSLog(@"looks like you already requested");
                }
            }else {
                NSLog(@"You are requesting yourself");
                NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
                UIColor *errorRed = [colors valueForKey:@"errorRed"];
                self.searchBar.barTintColor = errorRed;
            }
        }else {
            //Show that the username is invalid
            NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
            UIColor *errorRed = [colors valueForKey:@"errorRed"];
            self.searchBar.barTintColor = errorRed;
        }
    }
}

- (void)acceptFriendRequestFromFriendWithName:(NSString *)friendName
{
    //Core
    if (![[ZSSInsultStore sharedStore] coreFriendExists:friendName forUser:self.user]){
        //If friend isn't already there, create him
        ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreCreateFriend];
        friend.user = self.user;
        friend.pending = @NO;
        friend.wantsToAddUser = @NO;
        friend.friendName = friendName;
    }else {
        ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreFriendWithUsername:friendName forUser:self.user];
        friend.pending = @NO;
        friend.wantsToAddUser = @NO;
    }
    [[ZSSInsultStore sharedStore] saveChanges];
    
    //Parse
    PFQuery *notCurrentUserQuery = [PFUser query];
    [notCurrentUserQuery whereKey:@"username" equalTo:friendName];
    [notCurrentUserQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if ([objects count] == 1) {
            PFObject *friendship = [PFObject objectWithClassName:@"friendship"];
            friendship[@"user1"] = [PFUser currentUser];
            friendship[@"user2"] = [objects firstObject];
            [friendship saveInBackground];
            
            //Delete friend request notification
            PFQuery *notificationQuery = [PFQuery queryWithClassName:@"notification"];
            [notificationQuery whereKey:@"receiver" equalTo:[PFUser currentUser]];
            [notificationQuery whereKey:@"sender" equalTo:[objects firstObject]];
            [notificationQuery whereKey:@"type" equalTo:@"friendRequest"];
            [notificationQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                if ([objects count] == 1) {
                    PFObject *notification = [objects firstObject];
                    [notification deleteInBackground];
                }else{
                    NSLog(@"Could not find a notificatoin object to delete");
                }
                [self.tableView reloadData];
            }];
            
        }else{
            NSLog(@"could not find user with friendname:%@", friendName);
        }
    }];
    

    
    
}


- (void)confirmFriend:(PFUser *)newFriend
{
#pragma mark - Confirm Friend
    
    if (newFriend) {
        //Parse
        [[ZSSInsultStore sharedStore] acceptFriendRequestFromSender:newFriend toReceiver:[PFUser currentUser]];
        
        NSString *newFriendName = [newFriend valueForKey:@"username"];
        //Core
        ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreFriendWithUsername:self.searchBar.text forUser:self.user];
        if (friend) {
            friend.wantsToAddUser = @NO;
            friend.user = self.user;
            friend.pending = @NO;
            friend.friendName = newFriendName;
        } else {
            ZSSFriend *newFriend = [[ZSSInsultStore sharedStore] coreCreateFriend];
            newFriend.wantsToAddUser = @NO;
            newFriend.user = self.user;
            newFriend.pending = @NO;
            newFriend.friendName = newFriendName;
        }
        
        [[ZSSInsultStore sharedStore] saveChanges];
        
        
    }
    //fix views
    [self.tableView reloadData];
}

- (void)updateStatusOnFriendRequestWithSender:(PFUser *)sender
{
    PFQuery *request = [PFQuery queryWithClassName:@"friendRequest"];
    [request whereKey:@"sender" equalTo:sender];
    [request whereKey:@"receiver" equalTo:[PFUser currentUser]];
    NSArray *friendRequests = [request findObjects];
    for (PFObject *friendRequest in friendRequests) {
        friendRequest[@"confirmed"] = @YES;
        [friendRequest saveInBackground];
    }


}

- (void)eraseFriendRequestWithSender:(PFUser *)sender
{
    PFQuery *request = [PFQuery queryWithClassName:@"friendRequest"];
    [request whereKey:@"sender" equalTo:sender];
    [request whereKey:@"receiver" equalTo:[PFUser currentUser]];
    [request findObjectsInBackgroundWithBlock:^(NSArray *friendRequests, NSError *error) {
        if (!error){
            for (PFObject *friendRequest in friendRequests) {
                [friendRequest deleteInBackground];
            }
        }else {
            NSLog(@"error: %@", error);
        }
    }];
}
- (void)checkForConfirmations
{
    /*
    NSArray *friends = [PFUser currentUser][@"friends"];
    NSMutableArray *pendingFriends = [[NSMutableArray alloc] init];
    for (NSDictionary *friend in friends) {
        if ([[friends valueForKey:@"confirmed"]  isEqual: @NO]) {
            [pendingFriends addObject:friend];
        }
    }
    for (NSDictionary *friend in pendingFriends) {
        //Ensure user exists
        PFQuery *pendingFriend = [PFUser query];
        [pendingFriend whereKey:@"username" equalTo:self.searchBar.text];
        PFQuery *DidFriendConfirm = [PFQuery queryWithClassName:@"friendRequest"];
        [DidFriendConfirm whereKey:@"sender" equalTo:[PFUser currentUser]];
        
        [DidFriendConfirm whereKey:@"receiver" equalTo:[]
        [DidFriendConfirm whereKey:@"confirmed" equalTo:@YES];
    }
     */
    //NSArray *sentFriendRequests = [[PFUser currentUser] valueForKey:@"sentFriendRequests"];
    /*
    //Goes to Requests
    //For each request that is now @YES
    //Go to friends
    //If the friends name is equal to the newly @YES, then change the friends status to confirmed
    if ([sentFriendRequests count] != 0){
        for (PFObject *request in sentFriendRequests) {
            if ([[request fetchIfNeeded] valueForKey:@"confirmed"]) {
                for (NSDictionary *friend in [[PFUser currentUser] valueForKey:@"friends"]) {
                    if ([[friend valueForKey:@"user"] isEqual:[request valueForKey:@"receiver"]]){
                        [friend setValue:@YES forKey:@"confirmed"];
                        NSLog(@"Confirmed someone");
                    }
                }
            }
        }
    }
     */
}

- (void)checkForFriendRequests
{
    
    PFQuery *checkForFriendRequest = [PFQuery queryWithClassName:@"friendRequest"];
    [checkForFriendRequest includeKey:@"receiver"];
    [checkForFriendRequest whereKey:@"receiver" equalTo:[PFUser currentUser]];
    self.friendRequests = [checkForFriendRequest findObjects];
    NSLog(@"CheckForFriendRequests");
    NSLog(@"Found these friend requests: %@", self.friendRequests);
}

@end
