//
//  ZSSFriendTableViewCell.h
//  
//
//  Created by Zachary Shakked on 9/18/14.
//
//

#import <UIKit/UIKit.h>

@interface ZSSFriendTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *friendLabel;
@property (weak, nonatomic) IBOutlet UIButton *addFriendButton;
@property (nonatomic, copy) void (^actionBlock)(void);

@end
