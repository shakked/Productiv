//
//  ZSSFriendTableViewCell.m
//  
//
//  Created by Zachary Shakked on 9/18/14.
//
//

#import "ZSSFriendTableViewCell.h"

@implementation ZSSFriendTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)pressFriendButton:(id)sender
{
    self.actionBlock();
}

@end
