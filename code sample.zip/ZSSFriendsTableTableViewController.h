//
//  ZSSFriendsTableTableViewController.h
//  
//
//  Created by Zachary Shakked on 9/17/14.
//
//

#import <UIKit/UIKit.h>
#import "ZSSMessage.h"

@interface ZSSFriendsTableTableViewController : UITableViewController

@property (nonatomic, strong) NSString *insult;
@property (nonatomic, strong) ZSSMessage *message;
@property (nonatomic) BOOL fromHomeView;


@end
