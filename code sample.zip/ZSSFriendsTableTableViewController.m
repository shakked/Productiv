//
//  ZSSFriendsTableTableViewController.m
//  
//
//  Created by Zachary Shakked on 9/17/14.
//
//

#import "ZSSFriendsTableTableViewController.h"
#import <Parse/Parse.h>
#import "ZSSInsultStore.h"
#import "ZSSAddFriendTableViewController.h"
#import "ZSSFriendTableViewCell.h"

@interface ZSSFriendsTableTableViewController ()

@property (nonatomic, strong) NSManagedObject *user;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSMutableArray *sendList;
@property (nonatomic, strong) UIToolbar *sendBar;

@end

@implementation ZSSFriendsTableTableViewController

- (void)viewDidLoad {
    NSLog(@"%@", NSStringFromSelector(_cmd));

    [super viewDidLoad];
    
    UIButton *addFriendButton = [UIButton buttonWithType:UIButtonTypeCustom];
    addFriendButton.bounds = CGRectMake(0, 0, 40, 40);
    [addFriendButton setBackgroundImage:[UIImage imageNamed:@"add_user-50.png"] forState:UIControlStateNormal];
    UIBarButtonItem *addFriendBarButton = [[UIBarButtonItem alloc] initWithCustomView:addFriendButton];
    [addFriendButton addTarget:self action:@selector(addFriends) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = addFriendBarButton;
    
    self.navigationController.navigationBar.barTintColor = [UIColor redColor];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationItem.title = @"Friends";
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           NSFontAttributeName : [UIFont fontWithName:@"Georgia" size:28.0],
                                                           NSForegroundColorAttributeName : [UIColor whiteColor]
                                                           }];
    UINib *nib = [UINib nibWithNibName:@"ZSSFriendTableViewCell" bundle:nil];
    
    //Register this Nib, which contains the cell
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ZSSFriendTableViewCell"];
    NSLog(@"%@", NSStringFromSelector(_cmd));

}

- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"%@", NSStringFromSelector(_cmd));

    [super viewWillAppear:animated];
    
    PFUser *currentUser = [PFUser currentUser];
    NSString *username = [currentUser valueForKey:@"username"];
    NSManagedObject *user = [[ZSSInsultStore sharedStore] coreUserWithUsername:username];
    self.username = username;
    self.user = user;
    
    NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
    UIColor *cloudBlue = [colors valueForKey:@"cloudBlue"];
    [[UINavigationBar appearance] setTitleTextAttributes:@{
                                                           NSFontAttributeName : [UIFont fontWithName:@"Georgia" size:28.0],
                                                           NSForegroundColorAttributeName : [UIColor whiteColor]
                                                           }];
    
    self.navigationController.navigationBar.barTintColor = cloudBlue;
    
    //if from Home, show a cancel button
    if (self.fromHomeView) {
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(dismiss)];
        self.navigationItem.leftBarButtonItem = bbi;
    }
  
    //Load friends
    PFQuery *user1FriendQuery = [PFQuery queryWithClassName:@"friendship"];
    [user1FriendQuery whereKey:@"user1" equalTo:[PFUser currentUser]];
    PFQuery *user2FriendQuery = [PFQuery queryWithClassName:@"friendship"];
    [user2FriendQuery whereKey:@"user2" equalTo:[PFUser currentUser]];
    PFQuery *friendshipQuery = [PFQuery orQueryWithSubqueries:@[user1FriendQuery, user2FriendQuery]];
    [friendshipQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        //For each one, check if the friend is in the friend database
        //If neccessary, create friends accordingly
        for(PFObject *object in objects){
            NSString *user1Name = [[[object valueForKey:@"user1"] fetchIfNeeded] valueForKey:@"username"];
            NSString *user2Name = [[[object valueForKey:@"user2"] fetchIfNeeded] valueForKey:@"username"];
            
            //two cases
            if ([user1Name isEqual:self.username]){
                NSLog(@"user is user1: %@", user1Name);
                NSLog(@"friend is user2: %@", user2Name);
                //friend is user2
                ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreFriendWithUsername:user2Name forUser:self.user];
                friend.wantsToAddUser = @NO;
                friend.pending = @NO;
                
                //check if friend is in coredata already
                if(![[ZSSInsultStore sharedStore] coreFriendExists:user2Name forUser:self.user]){
                    NSLog(@"friend does not exists");
                    //friend does not exist
                    //create a friend in coreData
                    ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreCreateFriend];
                    friend.user = self.user;
                    friend.friendName = user2Name;
                    friend.wantsToAddUser = @NO;
                    friend.pending = @NO;
                    [[ZSSInsultStore sharedStore] saveChanges];
                    
                }
            }else if ([user2Name isEqual:self.username]){
                NSLog(@"user is user 2: %@", user2Name);
                NSLog(@"friend is user 1: %@", user1Name);
                ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreFriendWithUsername:user1Name forUser:self.user];
                friend.wantsToAddUser = @NO;
                friend.pending = @NO;
                //fiend is user1
                NSLog(@"friend does not exist");
                //check if friend is in coredata already
                if(![[ZSSInsultStore sharedStore] coreFriendExists:user1Name forUser:self.user]){
                    NSLog(@"friend is not in coredata");
                    //user does not exist
                    //create a friend in coreData
                    ZSSFriend *friend = [[ZSSInsultStore sharedStore] coreCreateFriend];
                    friend.user = self.user;
                    friend.friendName = user1Name;
                    friend.wantsToAddUser = @NO;
                    friend.pending = @NO;
                    [[ZSSInsultStore sharedStore] saveChanges];
                    NSLog(@"newly added friend: %@", friend);
    
                }
                
                
            }
        }
        NSArray *friends = [[ZSSInsultStore sharedStore] coreAllFriendsForUser:self.user];
        NSLog(@"friends:");
        NSLog(@"friends: %@", friends);
        [self.tableView reloadData];
        
    }];
    
    //SendList?
    //Message?
    //Create toolbar to send
    //sendcount
    
    if (self.message && [self.sendList count] > 0){
        //Show tabbar to Send
        UIBarButtonItem *flexibleSpaceBarButton = [[UIBarButtonItem alloc]
                                                   initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                   target:nil
                                                   action:nil];
        
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"sendWhite.png"]
                                                                style:UIBarButtonItemStylePlain
                                                               target:self
                                                               action:@selector(sendMessage)];
        
        [self.navigationController setToolbarHidden:NO animated:NO];
        [self setToolbarItems:@[flexibleSpaceBarButton, bbi] animated:NO];
        self.navigationController.toolbar.barTintColor = cloudBlue;
        self.navigationController.toolbar.translucent = NO;
        self.navigationController.toolbar.tintColor = [UIColor whiteColor];
    }
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController setToolbarHidden:YES];
    [[ZSSInsultStore sharedStore] saveChanges];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addFriends
{
    ZSSAddFriendTableViewController *aftvc = [[ZSSAddFriendTableViewController alloc] init];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:aftvc];
    
    [self presentViewController:nav animated:NO completion:nil];
    
}

- (void)sendMessage
{
    
    NSLog(@"the message that would be sent: %@", self.message);
    NSLog(@"the sendlist: %@", self.sendList);
    NSDate *currentDate = [NSDate date];
    
    if ([self.sendList count] == 1) {
        
        //Core
        self.message.sender = self.username;
        self.message.receiver = [[self.sendList firstObject] valueForKey:@"friendName"];
        self.message.dateSent = currentDate;
        NSLog(@"self.message: %@", self.message);
        [[ZSSInsultStore sharedStore] saveChanges];
        //Remove from sendlist
        [self.sendList removeObject:[self.sendList firstObject]];
        //Parse
        //Get Receiver User
        PFQuery *receiverQuery = [PFUser query];
        [receiverQuery whereKey:@"username" equalTo:self.message.receiver];
        [receiverQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
            //make the message
            PFUser *receiver = [objects firstObject];
            PFObject *message = [PFObject objectWithClassName:@"message"];
            message[@"receiver"] = receiver;
            message[@"sender"] = [PFUser currentUser];
            message[@"dateSent"] = currentDate;
            message[@"messageText"] = self.message.messageText;
            message[@"audioPitch"] = self.message.audioPitch;
            message[@"audioSpeed"] = self.message.audioSpeed;
            message[@"isAudio"] = self.message.isAudio;
            message[@"isText"] = self.message.isText;
            message[@"repeatCount"] = self.message.repeatCount;
            [message saveInBackground];
        }];
        
    }else if([self.sendList count] > 1){
        
        //finish current message
        //remove that user from the sendlist
        self.message.sender = self.username;
        self.message.receiver = [[self.sendList firstObject] valueForKey:@"friendName"];
        self.message.dateSent = currentDate;
        [[ZSSInsultStore sharedStore] saveChanges];
        [self.sendList removeObject:[self.sendList firstObject]];
        
        //Parse
        //Get Receiver User
        PFQuery *receiverQuery = [PFUser query];
        [receiverQuery whereKey:@"username" equalTo:self.message.receiver];
        [receiverQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
            //make the message
            PFUser *receiver = [objects firstObject];
            PFObject *message = [PFObject objectWithClassName:@"message"];
            message[@"receiver"] = receiver;
            message[@"sender"] = [PFUser currentUser];
            message[@"dateSent"] = currentDate;
            message[@"messageText"] = self.message.messageText;
            message[@"audioPitch"] = self.message.audioPitch;
            message[@"audioSpeed"] = self.message.audioSpeed;
            message[@"isAudio"] = self.message.isAudio;
            message[@"isText"] = self.message.isText;
            message[@"repeatCount"] = self.message.repeatCount;
            [message saveInBackground];
            
        }];
        
        //all other receivers
        for (NSManagedObject *receiver in self.sendList) {
            PFQuery *receiverQuery = [PFUser query];
            [receiverQuery whereKey:@"username" equalTo:[receiver valueForKey:@"friendName"]];
            [receiverQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                //make the message
                PFUser *receiver = [objects firstObject];
                PFObject *message = [PFObject objectWithClassName:@"message"];
                message[@"receiver"] = receiver;
                message[@"sender"] = [PFUser currentUser];
                message[@"dateSent"] = currentDate;
                message[@"messageText"] = self.message.messageText;
                message[@"audioPitch"] = self.message.audioPitch;
                message[@"audioSpeed"] = self.message.audioSpeed;
                message[@"isAudio"] = self.message.isAudio;
                message[@"isText"] = self.message.isText;
                message[@"repeatCount"] = self.message.repeatCount;
                [message saveInBackground];
                
                //Core
                ZSSMessage *messageCore = [[ZSSInsultStore sharedStore] coreCreateMessage];
                messageCore.receiver = [[receiver fetchIfNeeded]valueForKey:@"username"];
                messageCore.sender = [[PFUser currentUser] valueForKey:@"username"];
                messageCore.dateSent = currentDate;
                messageCore.messageText = self.message.messageText;
                messageCore.audioPitch = self.message.audioPitch;
                messageCore.audioSpeed = self.message.audioSpeed;
                messageCore.isAudio = self.message.isAudio;
                messageCore.isText = self.message.isText;
                messageCore.repeatCount = self.message.repeatCount;
                [[ZSSInsultStore sharedStore] saveChanges];
                [self.sendList removeObject:[self.sendList firstObject]];
            }];
            
            
        }
    }
    NSLog(@"Message sent successfully?");
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];

}

- (void)dismiss
{
    [[ZSSInsultStore sharedStore] coreDeleteMessage:self.message];
    [[ZSSInsultStore sharedStore] saveChanges];
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    NSLog(@"%@", NSStringFromSelector(_cmd));

    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.

    NSArray *confirmedFriends = [[ZSSInsultStore sharedStore] coreConfirmedFriendsForUser:self.user];
    return [confirmedFriends count];
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZSSFriendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ZSSFriendTableViewCell" forIndexPath:indexPath];
    
    if (indexPath.section == 0) {
        NSArray *friends = [[ZSSInsultStore sharedStore] coreConfirmedFriendsForUser:self.user];
        ZSSFriend *friend = friends[indexPath.row];
        cell.friendLabel.text = [friend valueForKey:@"friendName"];
        [cell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"unfilledBox.png"] forState:UIControlStateNormal];
    
        __weak ZSSFriendTableViewCell *weakCell = cell;
        cell.actionBlock = ^{
            ZSSFriendTableViewCell *strongCell = weakCell;

            if ([[strongCell.addFriendButton backgroundImageForState:UIControlStateNormal] isEqual: [UIImage imageNamed:@"unfilledBox.png"]]){
                [self addFriendToSendList:friend];
                [strongCell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"filledBox.png"] forState:UIControlStateNormal];
            } else {
                [self removeFriendFromSendList:friend];
                [strongCell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"unfilledBox.png"] forState:UIControlStateNormal];
            }
            
            if ([self.sendList count] > 0) {
                NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
                UIColor *cloudBlue = [colors valueForKey:@"cloudBlue"];
                [self.navigationController setToolbarHidden:NO animated:YES];
                UIBarButtonItem *flexibleSpaceBarButton = [[UIBarButtonItem alloc]
                                                           initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                           target:nil
                                                           action:nil];
                
                UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"sendWhite.png"]
                                                                        style:UIBarButtonItemStylePlain
                                                                       target:self
                                                                       action:@selector(sendMessage)];
                
                [self.navigationController setToolbarHidden:NO animated:NO];
                [self setToolbarItems:@[flexibleSpaceBarButton, bbi] animated:NO];
                self.navigationController.toolbar.barTintColor = cloudBlue;
                self.navigationController.toolbar.translucent = NO;
                self.navigationController.toolbar.tintColor = [UIColor whiteColor];
            } else {
                [self.navigationController setToolbarHidden:YES animated:NO];
            }
            
        };
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    return nil;

    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZSSFriendTableViewCell *cell = (ZSSFriendTableViewCell *)[self.tableView cellForRowAtIndexPath:indexPath];
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    if ([[cell.addFriendButton backgroundImageForState:UIControlStateNormal] isEqual: [UIImage imageNamed:@"unfilledBox.png"]]){
        [self addFriendToSendList:[[ZSSInsultStore sharedStore] coreFriendWithUsername:cell.friendLabel.text forUser:self.user]];
        [cell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"filledBox.png"] forState:UIControlStateNormal];
    } else {
        [self removeFriendFromSendList:[[ZSSInsultStore sharedStore] coreFriendWithUsername:cell.friendLabel.text forUser:self.user]];
        [cell.addFriendButton setBackgroundImage:[UIImage imageNamed:@"unfilledBox.png"] forState:UIControlStateNormal];
    }
    
    if ([self.sendList count] > 0) {
        NSDictionary *colors = [[ZSSInsultStore sharedStore] colors];
        UIColor *cloudBlue = [colors valueForKey:@"cloudBlue"];
        [self.navigationController setToolbarHidden:NO animated:YES];
        UIBarButtonItem *flexibleSpaceBarButton = [[UIBarButtonItem alloc]
                                                   initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                                   target:nil
                                                   action:nil];
        
        UIBarButtonItem *bbi = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"sendWhite.png"]
                                                                style:UIBarButtonItemStylePlain
                                                               target:self
                                                               action:@selector(sendMessage)];
        
        [self.navigationController setToolbarHidden:NO animated:NO];
        [self setToolbarItems:@[flexibleSpaceBarButton, bbi] animated:NO];
        self.navigationController.toolbar.barTintColor = cloudBlue;
        self.navigationController.toolbar.translucent = NO;
        self.navigationController.toolbar.tintColor = [UIColor whiteColor];
    } else {
        [self.navigationController setToolbarHidden:YES animated:NO];
    }

}

- (void)addFriendToSendList:(ZSSFriend *)friend
{
    if (!self.sendList) {
        self.sendList = [[NSMutableArray alloc] init];
    }
    [self.sendList addObject:friend];
    NSLog(@"self.sendList: %@", self.sendList);
    NSLog(@"adding someone");
}

- (void)removeFriendFromSendList:(ZSSFriend *)friend
{
    if (!self.sendList) {
        self.sendList = [[NSMutableArray alloc] init];
    }
    [self.sendList removeObject:friend];
    NSLog(@"removing someone");
    NSLog(@"self.sendList: %@", self.sendList);

}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
